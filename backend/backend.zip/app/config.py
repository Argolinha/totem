import os
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent.parent


class Settings:

    # ============================================================
    # DATABASE
    # ============================================================

    DATABASE_URL: str = os.getenv(
        "DATABASE_URL",
        f"sqlite:///{BASE_DIR / 'storage' / 'vive_photobooth.db'}"
    )

    # ============================================================
    # REDIS / CELERY
    # ============================================================

    REDIS_URL: str = os.getenv(
        "REDIS_URL",
        "redis://redis:6379/0"
    )

    CELERY_BROKER_URL: str = os.getenv(
        "CELERY_BROKER_URL",
        REDIS_URL
    )

    CELERY_RESULT_BACKEND: str = os.getenv(
        "CELERY_RESULT_BACKEND",
        REDIS_URL
    )

    # ============================================================
    # STORAGE
    # ============================================================

    STORAGE_DIR: Path = BASE_DIR / "storage"

    ORIGINAL_DIR: Path = STORAGE_DIR / "original"

    GENERATED_DIR: Path = STORAGE_DIR / "generated"

    FRAMES_DIR: Path = STORAGE_DIR / "frames"

    SCENES_DIR: Path = STORAGE_DIR / "scenes"

    # ============================================================
    # URL PÚBLICA
    # ============================================================

    PUBLIC_BASE_URL: str = os.getenv(
        "PUBLIC_BASE_URL",
        "http://localhost:8000"
    )

    # ============================================================
    # INTELIGÊNCIA ARTIFICIAL
    # ============================================================

    AI_PROVIDER: str = os.getenv(
        "AI_PROVIDER",
        "local"
    )

    # ------------------------------------------------------------
    # OpenAI
    # ------------------------------------------------------------

    OPENAI_API_KEY: str = os.getenv(
        "OPENAI_API_KEY",
        ""
    )

    OPENAI_TEXT_MODEL: str = os.getenv(
        "OPENAI_TEXT_MODEL",
        "gpt-4o-mini"
    )

    OPENAI_IMAGE_MODEL: str = os.getenv(
        "OPENAI_IMAGE_MODEL",
        "gpt-image-1"
    )

    # ------------------------------------------------------------
    # Stability AI
    # ------------------------------------------------------------

    STABILITY_API_KEY: str = os.getenv(
        "STABILITY_API_KEY",
        ""
    )

    # ------------------------------------------------------------
    # fal.ai
    # ------------------------------------------------------------

    FAL_KEY: str = os.getenv(
        "FAL_KEY",
        ""
    )

    FAL_FLUX_MODEL: str = os.getenv(
        "FAL_FLUX_MODEL",
        "fal-ai/flux/dev"
    )

    # ------------------------------------------------------------
    # InsightFace
    # ------------------------------------------------------------

    INSIGHTFACE_ENABLED: bool = (
        os.getenv(
            "INSIGHTFACE_ENABLED",
            "false"
        ).lower()
        in ("true", "1", "yes", "on")
    )

    INSIGHTFACE_MODEL_PACK: str = os.getenv(
        "INSIGHTFACE_MODEL_PACK",
        "buffalo_l"
    )

    INSIGHTFACE_ROOT: str = os.getenv(
        "INSIGHTFACE_ROOT",
        str(BASE_DIR / "models")
    )

    INSIGHTFACE_SWAPPER_MODEL_PATH: str = os.getenv(
        "INSIGHTFACE_SWAPPER_MODEL_PATH",
        str(BASE_DIR / "models" / "inswapper_128.onnx")
    )

    # ============================================================
    # EFEITOS PADRÃO
    # ============================================================

    AI_EFFECT_PROMPTS = [
        {
            "name": "Cartoon",
            "prompt": (
                "cartoon style, vibrant colors, clean lines, "
                "fun photobooth portrait"
            ),
        },
        {
            "name": "Cyberpunk",
            "prompt": (
                "cyberpunk style, neon lights, futuristic city, "
                "dramatic lighting"
            ),
        },
        {
            "name": "Fantasia",
            "prompt": (
                "fantasy style, magical atmosphere, "
                "epic lighting, cinematic"
            ),
        },
        {
            "name": "Pintura a Óleo",
            "prompt": (
                "oil painting style, classical art, "
                "textured brush strokes"
            ),
        },
        {
            "name": "Espaço",
            "prompt": (
                "astronaut in space, stars, galaxy background, "
                "cinematic lighting"
            ),
        },
        {
            "name": "Super-herói",
            "prompt": (
                "superhero style, dramatic pose, "
                "comic book art, cinematic lighting"
            ),
        },
    ]

    # ============================================================
    # DOWNLOAD
    # ============================================================

    DOWNLOAD_TOKEN_EXPIRATION: int = 60 * 60 * 24

    # ============================================================
    # TOTEM
    # ============================================================

    TOTEM_ID: str = os.getenv(
        "TOTEM_ID",
        "totem-001"
    )

    # ============================================================
    # CORS
    # ============================================================

    CORS_ORIGINS = os.getenv(
        "CORS_ORIGINS",
        (
            "http://localhost:5173,"
            "http://localhost:3000,"
            "http://localhost:8000"
        )
    ).split(",")

    # ============================================================
    # ADMIN
    # ============================================================

    AUTH_SECRET_KEY: str = os.getenv(
        "AUTH_SECRET_KEY",
        "vive-ai-photobooth-dev-secret-change-me"
    )

    ADMIN_EMAIL: str = os.getenv(
        "ADMIN_EMAIL",
        "admin@vive.local"
    )

    ADMIN_PASSWORD: str = os.getenv(
        "ADMIN_PASSWORD",
        "admin123"
    )


# ================================================================
# INSTÂNCIA GLOBAL
# ================================================================

settings = Settings()


# ================================================================
# CRIAÇÃO DAS PASTAS
# ================================================================

settings.STORAGE_DIR.mkdir(
    parents=True,
    exist_ok=True
)

settings.ORIGINAL_DIR.mkdir(
    parents=True,
    exist_ok=True
)

settings.GENERATED_DIR.mkdir(
    parents=True,
    exist_ok=True
)

settings.FRAMES_DIR.mkdir(
    parents=True,
    exist_ok=True
)

settings.SCENES_DIR.mkdir(
    parents=True,
    exist_ok=True
)
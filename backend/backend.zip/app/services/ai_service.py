"""
Orquestrador de IA - Vive AI Photobooth
=========================================

Gera as N variações temáticas da foto do totem combinando até 5 mecanismos
de IA, sempre com fallback local garantindo que o totem NUNCA trava mesmo
sem internet:

  1. fal.ai (FLUX img2img)    -> aplica o cenário temático completo (fal-ai/flux)
  2. InsightFace (local/ONNX) -> troca de rosto na cena gerada (roda OFFLINE)
  3. OpenAI (gpt-image-1)     -> gera/edita a variação usando GPT/Images API
  4. Stability AI (SD3.5)     -> provedor extra opcional, mesmo contrato de plugin
  5. Motor local (Pillow)     -> fallback 100% offline, sempre disponível,
     compõe o rosto do usuário sobre a imagem de cena local (storage/scenes/*)
     quando nenhum provedor externo está disponível.

Estratégia (settings.AI_PROVIDER):
  - "auto"        (recomendado): fal -> insightface -> openai -> stability -> local
  - "fal" | "insightface" | "openai" | "stability": força um provedor específico,
    com fallback automático para "local" em caso de falha/timeout/sem internet.
  - "local": nunca sai para a internet.

Cada função `generate_with_<provider>` recebe (image, efeito) e devolve uma
PIL.Image.Image final (já composta) ou levanta exceção, que o orquestrador
captura para passar ao próximo provedor da cadeia.
"""
from __future__ import annotations

import base64
import io
import logging
import socket
from pathlib import Path
from typing import List, Optional, Tuple

import httpx
from PIL import Image, ImageEnhance, ImageFilter, ImageOps

from app.config import settings

logger = logging.getLogger(__name__)

# Cadeia de fallback usada quando AI_PROVIDER="auto"
DEFAULT_CHAIN = ["fal", "insightface", "openai", "stability", "local"]


def has_internet_connection(host: str = "8.8.8.8", port: int = 53, timeout: float = 2.0) -> bool:
    try:
        socket.setdefaulttimeout(timeout)
        socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect((host, port))
        return True
    except OSError:
        return False


def _effect_scene_path(efeito: dict) -> Optional[Path]:
    scene_file = efeito.get("scene_file")
    if not scene_file:
        return None
    path = settings.SCENES_DIR / scene_file
    return path if path.exists() else None


# ---------------------------------------------------------------------------
# 1) fal.ai - FLUX (image-to-image, estilo/cenário temático)
# ---------------------------------------------------------------------------

def generate_with_fal(image: Image.Image, efeito: dict) -> Image.Image:
    if not settings.FAL_KEY:
        raise RuntimeError("FAL_KEY não configurada")

    buf = io.BytesIO()
    image.convert("RGB").save(buf, format="JPEG", quality=92)
    image_b64 = base64.b64encode(buf.getvalue()).decode()
    data_uri = f"data:image/jpeg;base64,{image_b64}"

    payload = {
        "image_url": data_uri,
        "prompt": efeito["prompt"] + ", photorealistic, high detail, preserve facial identity",
        "strength": 0.55,  # preserva identidade facial mantendo o estilo do cenário
        "num_inference_steps": 28,
        "guidance_scale": 3.5,
    }
    headers = {"Authorization": f"Key {settings.FAL_KEY}", "Content-Type": "application/json"}
    url = f"https://queue.fal.run/{settings.FAL_FLUX_MODEL}"

    with httpx.Client(timeout=60.0) as client:
        resp = client.post(url, json=payload, headers=headers)
        resp.raise_for_status()
        result = resp.json()
        # fal.ai usa fila assíncrona: se vier status_url, faz polling
        if "response_url" in result or "status_url" in result:
            status_url = result.get("status_url") or result["response_url"]
            response_url = result.get("response_url", status_url)
            import time
            for _ in range(30):
                s = client.get(status_url, headers=headers)
                s.raise_for_status()
                sdata = s.json()
                if sdata.get("status") == "COMPLETED":
                    result = client.get(response_url, headers=headers).json()
                    break
                time.sleep(2)
        image_url = result["images"][0]["url"]
        img_resp = client.get(image_url)
        img_resp.raise_for_status()
        return Image.open(io.BytesIO(img_resp.content)).convert("RGB")


# ---------------------------------------------------------------------------
# 2) InsightFace - troca de rosto local (ONNX), funciona 100% OFFLINE
# ---------------------------------------------------------------------------

_insightface_app = None
_insightface_swapper = None


def _load_insightface():
    """Carrega os modelos InsightFace sob demanda (lazy) e mantém em cache no processo."""
    global _insightface_app, _insightface_swapper
    if _insightface_app is not None:
        return _insightface_app, _insightface_swapper

    import insightface  # type: ignore
    from insightface.app import FaceAnalysis  # type: ignore

    app_ = FaceAnalysis(name=settings.INSIGHTFACE_MODEL_PACK, root=settings.INSIGHTFACE_ROOT)
    app_.prepare(ctx_id=0, det_size=(640, 640))

    swapper_path = Path(settings.INSIGHTFACE_SWAPPER_MODEL_PATH)
    if not swapper_path.exists():
        raise RuntimeError(
            f"Modelo inswapper não encontrado em {swapper_path}. "
            "Baixe 'inswapper_128.onnx' e coloque nesse caminho para habilitar troca de rosto offline."
        )
    swapper_ = insightface.model_zoo.get_model(str(swapper_path))

    _insightface_app, _insightface_swapper = app_, swapper_
    return _insightface_app, _insightface_swapper


def generate_with_insightface(image: Image.Image, efeito: dict) -> Image.Image:
    """
    Troca o rosto da imagem de cena temática (storage/scenes/<efeito>.jpg) pelo
    rosto capturado no totem. Roda 100% local/offline (sem chamadas de rede) -
    ideal como camada de geração de rosto quando não há internet.
    """
    if not settings.INSIGHTFACE_ENABLED:
        raise RuntimeError("InsightFace desabilitado (INSIGHTFACE_ENABLED=false)")

    scene_path = _effect_scene_path(efeito)
    if scene_path is None:
        raise RuntimeError(f"Sem imagem de cena local para o efeito '{efeito['name']}' (storage/scenes/)")

    import cv2  # type: ignore
    import numpy as np  # type: ignore

    face_app, swapper = _load_insightface()

    source_cv = cv2.cvtColor(np.array(image.convert("RGB")), cv2.COLOR_RGB2BGR)
    scene_img = Image.open(scene_path).convert("RGB")
    target_cv = cv2.cvtColor(np.array(scene_img), cv2.COLOR_RGB2BGR)

    source_faces = face_app.get(source_cv)
    target_faces = face_app.get(target_cv)
    if not source_faces:
        raise RuntimeError("Nenhum rosto detectado na foto original")
    if not target_faces:
        raise RuntimeError(f"Nenhum rosto detectado na cena '{scene_path.name}'")

    result_cv = target_cv.copy()
    for tf in target_faces:
        result_cv = swapper.get(result_cv, tf, source_faces[0], paste_back=True)

    result_rgb = cv2.cvtColor(result_cv, cv2.COLOR_BGR2RGB)
    return Image.fromarray(result_rgb)


# ---------------------------------------------------------------------------
# 3) OpenAI (ChatGPT p/ prompt + gpt-image-1 p/ edição de imagem)
# ---------------------------------------------------------------------------

def _openai_refine_prompt(base_prompt: str) -> str:
    """Usa o ChatGPT para enriquecer o prompt de estilo antes de gerar a imagem."""
    headers = {"Authorization": f"Bearer {settings.OPENAI_API_KEY}", "Content-Type": "application/json"}
    body = {
        "model": settings.OPENAI_TEXT_MODEL,
        "messages": [
            {
                "role": "system",
                "content": "Você é um diretor de arte. Reescreva o prompt de estilo em uma frase técnica e "
                "vívida em inglês para um modelo de geração de imagens, preservando o pedido original.",
            },
            {"role": "user", "content": base_prompt},
        ],
        "max_tokens": 120,
        "temperature": 0.7,
    }
    with httpx.Client(timeout=20.0) as client:
        resp = client.post("https://api.openai.com/v1/chat/completions", json=body, headers=headers)
        resp.raise_for_status()
        return resp.json()["choices"][0]["message"]["content"].strip()


def generate_with_openai(image: Image.Image, efeito: dict) -> Image.Image:
    if not settings.OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY não configurada")

    try:
        prompt = _openai_refine_prompt(efeito["prompt"])
    except Exception:  # noqa: BLE001
        prompt = efeito["prompt"]

    buf = io.BytesIO()
    image.convert("RGBA").save(buf, format="PNG")
    buf.seek(0)

    headers = {"Authorization": f"Bearer {settings.OPENAI_API_KEY}"}
    files = {"image": ("original.png", buf, "image/png")}
    data = {
        "model": settings.OPENAI_IMAGE_MODEL,
        "prompt": f"Transform this portrait into: {prompt}. Keep the same person's facial identity recognizable.",
        "size": "1024x1024",
        "n": 1,
    }
    with httpx.Client(timeout=60.0) as client:
        resp = client.post("https://api.openai.com/v1/images/edits", data=data, files=files, headers=headers)
        resp.raise_for_status()
        result = resp.json()
        b64 = result["data"][0]["b64_json"]
        return Image.open(io.BytesIO(base64.b64decode(b64))).convert("RGB")


# ---------------------------------------------------------------------------
# 4) Stability AI (provedor extra opcional - mesmo contrato de plugin)
# ---------------------------------------------------------------------------

def generate_with_stability(image: Image.Image, efeito: dict) -> Image.Image:
    if not settings.STABILITY_API_KEY:
        raise RuntimeError("STABILITY_API_KEY não configurada")

    buf = io.BytesIO()
    image.convert("RGB").save(buf, format="PNG")
    buf.seek(0)

    headers = {"Authorization": f"Bearer {settings.STABILITY_API_KEY}", "Accept": "image/*"}
    files = {"image": ("original.png", buf, "image/png")}
    data = {"prompt": efeito["prompt"], "mode": "image-to-image", "strength": 0.55, "output_format": "jpeg"}
    url = "https://api.stability.ai/v2beta/stable-image/generate/sd3"

    with httpx.Client(timeout=60.0) as client:
        resp = client.post(url, headers=headers, files=files, data=data)
        resp.raise_for_status()
        return Image.open(io.BytesIO(resp.content)).convert("RGB")


# ---------------------------------------------------------------------------
# 5) Motor local (Pillow) - SEMPRE disponível, 100% offline, sem custo de API.
#    É o fallback final e também compõe o rosto sobre a cena local quando existir.
# ---------------------------------------------------------------------------

def generate_with_local(image: Image.Image, efeito: dict) -> Image.Image:
    name = efeito["name"]
    img = image.copy().convert("RGB")

    scene_path = _effect_scene_path(efeito)
    if scene_path is not None:
        # Composição simples e determinística: mescla a cena temática com a foto
        # do usuário (sem exigir detecção facial), garantindo resultado sempre
        # disponível offline mesmo sem InsightFace instalado.
        scene = Image.open(scene_path).convert("RGB").resize(img.size)
        img = Image.blend(scene, img, alpha=0.55)

    if name == "Cartoon":
        img = img.filter(ImageFilter.SMOOTH_MORE)
        img = ImageEnhance.Color(img).enhance(1.8)
        img = ImageEnhance.Contrast(img).enhance(1.3)
    elif name == "Cyberpunk":
        img = ImageEnhance.Color(img).enhance(2.2)
        r, g, b = img.split()
        b = ImageEnhance.Brightness(b).enhance(1.4)
        img = Image.merge("RGB", (r, g, b))
    elif name == "Fantasia":
        img = ImageEnhance.Brightness(img).enhance(1.15)
        img = ImageEnhance.Color(img).enhance(1.5)
        img = img.filter(ImageFilter.GaussianBlur(radius=0.6))
    elif name == "Pintura a Óleo":
        img = img.filter(ImageFilter.EDGE_ENHANCE_MORE)
        img = img.filter(ImageFilter.SMOOTH)
    elif name == "Espaço":
        img = ImageOps.autocontrast(img)
        img = ImageEnhance.Color(img).enhance(0.6)
        img = ImageEnhance.Brightness(img).enhance(0.85)
    elif name == "Super-herói":
        img = ImageEnhance.Contrast(img).enhance(1.6)
        img = ImageEnhance.Sharpness(img).enhance(2.0)
    else:
        img = ImageOps.autocontrast(img)

    return img


PROVIDER_FUNCTIONS = {
    "fal": generate_with_fal,
    "insightface": generate_with_insightface,
    "openai": generate_with_openai,
    "stability": generate_with_stability,
    "local": generate_with_local,
}


def _resolve_chain(efeito: dict) -> List[str]:
    """Define a ordem de tentativa de provedores para este efeito específico."""
    preferred = efeito.get("provider_preferido")
    if settings.AI_PROVIDER == "local":
        return ["local"]
    if settings.AI_PROVIDER != "auto" and settings.AI_PROVIDER in PROVIDER_FUNCTIONS:
        chain = [settings.AI_PROVIDER]
    elif preferred and preferred in PROVIDER_FUNCTIONS:
        chain = [preferred]
    else:
        chain = list(DEFAULT_CHAIN)

    if "local" not in chain:
        chain.append("local")  # o motor local é sempre a rede de segurança final
    return chain


def generate_single_variation(image: Image.Image, efeito: dict, online: bool) -> Tuple[Image.Image, str]:
    """Gera uma variação tentando a cadeia de provedores até um funcionar."""
    chain = _resolve_chain(efeito)
    last_error: Optional[Exception] = None

    for provider in chain:
        if provider not in ("local", "insightface") and not online:
            # Provedores em nuvem exigem internet; pula direto para o próximo.
            continue
        try:
            fn = PROVIDER_FUNCTIONS[provider]
            result = fn(image, efeito)
            return result, provider
        except Exception as exc:  # noqa: BLE001
            last_error = exc
            logger.warning("Provedor '%s' falhou para efeito '%s': %s", provider, efeito["name"], exc)
            continue

    logger.error("Todos os provedores falharam para efeito '%s': %s", efeito["name"], last_error)
    raise RuntimeError(f"Falha ao gerar variação '{efeito['name']}': {last_error}")


def _sanitize_filename(name: str) -> str:
    replacements = {"á": "a", "à": "a", "ã": "a", "â": "a", "é": "e", "ê": "e",
                    "í": "i", "ó": "o", "ô": "o", "õ": "o", "ú": "u", "ç": "c"}
    result = name.lower().replace(" ", "_")
    for a, b in replacements.items():
        result = result.replace(a, b)
    return result


def generate_variations(
    original_path: Path,
    output_dir: Path,
    session_id: str,
    efeitos: Optional[List[dict]] = None,
) -> Tuple[List[str], List[str], List[str]]:
    """
    Ponto de entrada único usado pela task do Celery.

    `efeitos`: lista de dicts {name, prompt, scene_file, provider_preferido}.
    Se None, usa settings.AI_EFFECT_PROMPTS (fallback de compatibilidade).

    Retorna (caminhos_gerados, nomes_dos_efeitos, provedores_usados).
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    image = Image.open(original_path)
    online = has_internet_connection()

    effect_list = efeitos or settings.AI_EFFECT_PROMPTS

    generated_paths: List[str] = []
    effect_names: List[str] = []
    providers_used: List[str] = []

    for i, effect in enumerate(effect_list):
        result_img, provider = generate_single_variation(image, effect, online)

        filename = f"{session_id}_{i}_{_sanitize_filename(effect['name'])}.jpg"
        filepath = output_dir / filename
        result_img.convert("RGB").save(filepath, "JPEG", quality=90)

        generated_paths.append(str(filepath))
        effect_names.append(effect["name"])
        providers_used.append(provider)

    return generated_paths, effect_names, providers_used
